# Use col="color" to add a color to the points:
plot(1:10, col="red")