#Draw one point in the diagram, at position (1) and position (3):
plot(1, 3)