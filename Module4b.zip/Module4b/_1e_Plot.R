#If you want to draw dots in a sequence, on both the x-axis and the y-axis, use the : operator:

plot(1:10)