#Draw two points in the diagram, one at position (1, 3) and one in position (8, 10):
plot(c(1, 8), c(3, 10))