#For better organization, when you have many values, it is better to use variables:
x <- c(1, 2, 3, 4, 5)
y <- c(3, 7, 8, 9, 12)

plot(x, y)