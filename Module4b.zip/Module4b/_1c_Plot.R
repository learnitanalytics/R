#You can plot as many points as you like, just make sure you have the same number of points in both axis:
plot(c(1, 2, 3, 4, 5), c(3, 7, 8, 9, 12))