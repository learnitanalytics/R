#Use pch with a value from 0 to 25 to change the point shape format:
#Try 1-25
plot(1:10, pch=25, cex=2)
