#The plot() function also takes a type parameter with the value l to draw a line to connect all the points in the diagram:
plot(1:10, type="l")