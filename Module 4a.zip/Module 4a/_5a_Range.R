#The range is the difference between the largest and the smallest value in a dataset.
data <- c(1, 3, NA, 5, 16, 18, 22, 25, 29)

#calculate range
max(data, na.rm=TRUE) - min(data, na.rm=TRUE)