#create data frame
df <- data.frame(x=c(1, 3, NA, 5, 16, 18, 22, 25),
                 y=c(NA, 4, 8, 9, 14, 23, 29, 31),
                 z=c(2, NA, 9, 4, 13, 17, 22, 24))

#find range of all values in entire data frame
max(df, na.rm=TRUE) - min(df, na.rm=TRUE)