#var(y) instructs R to calculate the sample variance of Y. In other words it uses n-1 'degrees of freedom', where n is the number of observations in Y.
#sd(y) instructs R to return the sample standard deviation of y, using n-1 degrees of freedom.
#sd(y) = sqrt(var(y)). In other words, this is the uncorrected sample standard deviation.

# 'pop. var.' where n > 1
n=length(y); var(y)*(n-1)/n

# 'pop. var.' where n > 0
mean((y-mean(y))^2)