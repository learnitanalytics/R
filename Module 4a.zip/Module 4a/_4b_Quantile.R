# R program to create
# quantiles of a data set

# Calling pre-defined data set
BOD

# Calling quantile() Function
quantile(BOD$demand)
quantile(BOD$Time)