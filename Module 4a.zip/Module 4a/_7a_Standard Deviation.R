#Standard Deviation is the square root of variance. It is a measure of the extent to which data varies from the mean

# R program to get 
# standard deviation of a list

# Taking a list of elements
list = c(2, 4, 4, 4, 5, 5, 7, 9)

# Calculating standard 
# deviation using sd()
print(sd(list))