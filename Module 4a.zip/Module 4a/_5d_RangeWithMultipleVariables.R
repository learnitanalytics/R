#create data frame
df <- data.frame(x=c(1, 3, NA, 5, 16, 18, 22, 25),
                 y=c(NA, 4, 8, 9, 14, 23, 29, 31),
                 z=c(2, NA, 9, 4, 13, 17, 22, 24))

#find range of variable x and y in the data frame
sapply(df[c('x','y')], function(df) max(df, na.rm=TRUE) - min(df, na.rm=TRUE))


#find range of all variables in the data frame
sapply(df, function(df) max(df, na.rm=TRUE) - min(df, na.rm=TRUE))