#quantile() function in R Language is used to create sample quantiles within a data set with probability[0, 1]. 
#Such as first quantile is at 0.25[25%], second is at 0.50[50%], and third is at 0.75[75%].
# R program to create
# quantiles of a data set
# Create a data frame 

d <- data.frame( name = c("Abhi", "Bhavesh", "Chaman", "Dimri"),  
                 age = c(7, 5, 9, 16),  
                 ht = c(46, NA, NA, 69), 
                 school = c("yes", "yes", "no", "no") )

# Calling quantile() Function
quantile(d$age)