data <- c(1, 3, NA, 5, 16, 18, 22, 25, 29)

#calculate range values
range(data, na.rm=TRUE)