#Remember if n=1 the second variance formula will always yield zero, because the mean of y will equal y, whereas the first formula will always yield NA, because 0/(1-1) = 0/0 and cannot be evaluated.
#Similarly, to obtain the 'population' standard deviation, use:

sqrt(mean((y-mean(y))^2))
  