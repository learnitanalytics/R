# Create a vector.
#When trim parameter is supplied, the values in the vector get sorted and then the required numbers of observations are dropped from calculating the mean.
#When trim = 0.3, 3 values from each end will be dropped from the calculations to find mean.

x <- c(12,7,3,4.2,18,2,54,-21,8,-5)

# Find Mean.
result.mean <-  mean(x,trim = 0.3)
print(result.mean)